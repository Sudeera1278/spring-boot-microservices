package com.order.order.common;

public interface OrderResponse {}
